# Indonesian language evaluation — synthetic practice portfolio
# Portofolio latihan evaluasi bahasa Indonesia — data sintetis

Independent learning material created for CV Studio. Not produced by, endorsed by,
or taken from Alignerr. No real client, customer, confidential or assessment data.
Materi belajar mandiri CV Studio; bukan materi atau dukungan Alignerr.

## Contents / Isi
- translation-worked.csv: 10 English–Indonesian translation reviews with corrections
  and explanations in both languages. / 10 contoh review terjemahan bilingual.
- register-worked.csv: 8 original Indonesian scenarios covering audience, tone,
  cultural assumptions, acceptable text and uncertain context. / 8 skenario review.
- translation-worksheet.csv and register-worksheet.csv: the same synthetic inputs,
  with review fields empty. / Input sama dengan kolom review kosong.
- rubric.md: decision rules, limits and a repeatable second-pass checklist.

Open CSV files in Excel, LibreOffice or a text editor (UTF-8, comma separated).
Buka CSV menggunakan encoding UTF-8 dan pemisah koma.

## Build your own evidence / Buat bukti Anda sendiri
1. Read the rubric. Complete the blank worksheets before reading worked examples.
   Baca rubrik; kerjakan lembar kosong sebelum melihat contoh jawaban.
2. Explain each correction in Indonesian and English. Several revisions can be valid.
   Jelaskan koreksi dalam kedua bahasa; jawaban tidak selalu tunggal.
3. Recheck your work; save a dated correction log, including unchanged decisions.
   Periksa ulang; simpan tanggal dan catatan koreksi, termasuk keputusan yang tetap.
4. Add at least 5 original synthetic items covering your weakest issue category.
   Tambahkan setidaknya 5 item sintetis buatan sendiri untuk kategori yang sulit.
5. Keep your own files and a one-page note explaining method, limits and lessons.
   Simpan file sendiri serta catatan satu halaman tentang metode dan pelajaran.

The worked reviews are examples, not authoritative gold labels or benchmark scores.
No model was tested, and no accuracy rate, client result or inter-reviewer agreement
is implied. Merely downloading this pack does not make its reviews your achievements.
Contoh jawaban bukan label baku atau nilai benchmark. Mengunduh paket ini bukan
bukti bahwa Anda mengerjakan review. Jangan mengklaim hasil penulis sebagai hasil Anda.

## CV wording after completing your own work / Setelah latihan sendiri selesai
English: Reviewed [actual number] synthetic English–Indonesian pairs using a rubric
for meaning, naturalness and register; recorded corrections and bilingual rationales.
Indonesia: Meninjau [jumlah sebenarnya] pasangan Inggris–Indonesia sintetis dengan
rubrik makna, keluwesan, dan register; mencatat koreksi serta alasan bilingual.
State “practice project / proyek latihan”. Omit uncompleted tasks and proficiency
claims you cannot demonstrate. A public URL is optional; local files can be reviewed.

Target vacancy (check current requirements): Indonesian Language Expert, Alignerr
https://www.alignerr.com/jobs/0d4200ef-e969-42d0-a977-18211895fe67
Job checked 9 October 2026; these cases were written independently for practice.
