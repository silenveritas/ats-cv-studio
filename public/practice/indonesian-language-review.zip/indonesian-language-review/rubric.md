# Review rubric / Rubrik review

Purpose: evaluate written language quality, not candidate scores or hiring chances.
Tujuan: mengevaluasi kualitas tulisan, bukan skor kandidat atau peluang diterima.

## Dimensions / Dimensi
1. Meaning / Makna: preserve negation, conditions, time windows, numbers, modality
   and intent. Flag omissions, additions or an unsupported certainty change.
2. Naturalness / Keluwesan: avoid literal expressions and awkward word choices;
   keep a valid sentence unchanged when a rewrite adds no value.
3. Register / Register: compare tone with the stated audience, channel and purpose.
   Formal is not always better; informal wording may fit an internal chat.
4. Cultural context / Konteks budaya: question unsupported assumptions about
   religion, gender, family roles or schedules. Ask for context before rewriting.
5. Feedback / Feedback: propose a concise correction and explain the specific
   problem in Indonesian and English. Do not merely write “sounds better”.

## Decision labels / Label keputusan
- acceptable + none: no material issue / tidak ada masalah yang perlu diperbaiki.
- issue + minor: meaning retained, but style or tone needs a local correction /
  makna tetap, gaya atau nada perlu perbaikan.
- issue + major: meaning, safety instruction or essential intent changes /
  makna, instruksi keamanan, atau maksud penting berubah.
- issue + context needed: no defensible final answer without clarification /
  keputusan akhir memerlukan konteks. Record the exact question to ask.
These are practice labels, not a claim of Alignerr's internal grading standard.
Ini label latihan, bukan klaim standar penilaian internal Alignerr.

## Second pass / Pemeriksaan ulang
- Match each revision to the source and stated audience, sentence by sentence.
- Recheck negation, restrictions (“only”), certainty (“may”), deadlines and omissions.
- Check spelling, consistency and glossary choices without over-editing valid text.
- Confirm bilingual rationales describe the same decision.
- Keep unresolved questions visible; never fill gaps with invented facts.
- Save item ID, first decision, revised decision, reason and review date in a log.

Self-review checks your own consistency; it does not establish agreement with other
reviewers or model accuracy. Pemeriksaan mandiri tidak membuktikan kesepakatan
antar-reviewer atau akurasi model. Dialect expertise needs independent evidence.
